# -*- coding: utf-8 -*-
# Run: python test_imdb.py
# Standalone check of IMDB/Trakt classification + parsing (stubs Kodi/network).
import json
import os
import sys
import types

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib')


def stub(name, **attrs):
    mod = types.ModuleType(name)
    for k, v in attrs.items():
        setattr(mod, k, v)
    sys.modules[name] = mod
    return mod


class FakeAddon:
    def getAddonInfo(self, k): return 'x'
    def getSetting(self, k): return 'false'
    def getSettingBool(self, k): return False
    def setSetting(self, *a): pass
    def getLocalizedString(self, k): return 'str%s' % k
    def openSettings(self): pass


class FakeResp:
    def __init__(self, content=b''):
        self.content = content
        self.status_code = 200
    @property
    def text(self): return self.content.decode('utf-8', 'replace')
    @property
    def headers(self): return {'Content-Type': 'text/html'}
    def raise_for_status(self): pass
    def json(self): return json.loads(self.content)


class Mon:
    def abortRequested(self): return False
    def waitForAbort(self, *a): return False


RESP = {}
def _get(url, *a, **k):
    for key in RESP:
        if key in url:
            return RESP[key]
    raise AssertionError('no stub for url %s' % url)
stub('requests', get=_get)
stub('xbmc', LOGDEBUG=0, LOGINFO=2, LOGWARNING=3, LOGERROR=4,
     Monitor=lambda: Mon(), Player=object, InfoTagVideo=object,
     log=lambda *a: None, executeJSONRPC=lambda *a: '{}',
     getCondVisibility=lambda *a: False, executebuiltin=lambda *a: None)
xbmcgui = stub('xbmcgui', Window=object, Dialog=object, ListItem=object,
               DialogProgressBG=object, NOTIFICATION_INFO=0)
stub('xbmcaddon', Addon=lambda id: FakeAddon())
stub('xbmcplugin')
stub('xbmcvfs', translatePath=lambda p: p, File=object, exists=lambda p: False)
stub('kodi_six', xbmc=sys.modules['xbmc'], xbmcaddon=sys.modules['xbmcaddon'],
     xbmcplugin=sys.modules['xbmcplugin'], xbmcgui=xbmcgui, xbmcvfs=sys.modules['xbmcvfs'])
stub('infotagger', listitem=stub('infotagger.listitem', ListItemInfoTag=object))
stub('simplecache', SimpleCache=object)
stub('simplecache.simplecache', SimpleCache=object)


class _Script:
    string = ''


class _Soup:
    def __init__(self, string):
        self._string = string
    def find(self, *a, **k):
        s = _Script(); s.string = self._string; return s
    def find_all(self, *a, **k):
        return []


stub('bs4', BeautifulSoup=lambda content, parser: _Soup(content.decode('utf-8', 'replace')))

sys.path.insert(0, ROOT)
from parsers import imdb, trakt  # noqa: E402

m = imdb.IMDB.__new__(imdb.IMDB)

assert m.classify('Movie') == 'movies'
assert m.classify('TV Series') == 'tvshows'
assert m.classify('tvMiniSeries') == 'tvshows'
assert m.classify('TV Episode') == 'episodes'
assert m.classify('Video') is None
assert m.classify('') is None
assert m.classify(None) is None

CSV = ('\ufeffPosition,Const,Created,Modified,Description,Title,URL,Title Type,IMDb Rating,Runtime (mins),Year,Genres,Num Votes,Release Date,Directors\n'
       '1,tt0111161,,,,"The Shawshank Redemption",https://www.imdb.com/title/tt0111161/,Movie,9.3,142,1994,"Drama, Crime",2870496,1994-10-14,Frank Darabont\n'
       '2,tt0944947,,,,"Game of Thrones",https://www.imdb.com/title/tt0944947/,TV Series,9.2,57,2011,"Action, Adventure, Drama",2369769,2011-04-17,David Benioff\n'
       '3,tt1480055,,,,"The Walking Dead",https://www.imdb.com/title/tt1480055/,TV Mini Series,8.2,45,2010,"Drama, Horror",1144290,2010-10-31,Frank Darabont\n'
       '4,tt0944947,,,,"Winter Is Coming",https://www.imdb.com/title/tt1480055/,TV Episode,9.0,57,2011,"Action, Adventure, Drama",2369769,2011-04-17,Timothy Van Patten\n'
       '5,tt0111161,,,,"Some Video",https://www.imdb.com/title/tt0111161/,Video,5.0,10,2000,"X",1,,John')
d = m._parse_csv(CSV)
assert sorted(d) == ['episodes', 'movies', 'tvshows'], sorted(d)
assert d['movies'][0]['uniqueid'] == {'imdb': 'tt0111161'}
assert len(d['movies']) == 1 and len(d['tvshows']) == 2 and len(d['episodes']) == 1

PAGE = ('{"props":{"pageProps":{"contentData":{"list":{"items":['
        '{"item":{"id":"tt1","titleText":{"text":"A"},"titleType":{"id":"movie"}}},'
        '{"item":{"id":"tt2","titleText":{"text":"B"},"titleType":{"id":"tvSeries"}}},'
        '{"item":{"id":"tt3","titleText":{"text":"C"},"titleType":{"id":"video"}}}'
        ']}}}}}').encode('utf-8')
RESP['ls123'] = FakeResp(PAGE)
d2 = m._parse_page('ls123', {})
assert sorted(d2) == ['movies', 'tvshows'], sorted(d2)
assert d2['movies'][0]['uniqueid'] == {'imdb': 'tt1'}

assert m._parse_csv('<html><body>blocked</body></html>') == {}

t = trakt.Trakt.__new__(trakt.Trakt)
t.monitor = Mon()

PERSON = [{'type': 'person', 'person': {'name': 'Tom Hanks', 'ids': {'trakt': 100, 'slug': 'tom-hanks'}}}]
MOVIES = [{'type': 'movie', 'movie': {'title': 'Toy Story', 'year': 1995, 'ids': {'trakt': 1, 'imdb': 'tt0114709'}}}]
SHOWS  = [{'type': 'show',  'show':  {'title': 'The Pacific', 'year': 2010, 'ids': {'trakt': 2, 'imdb': 'tt0374463'}}}]
SEASONS= [{'type': 'season', 'season': {'number': 1, 'ids': {'trakt': 3}}, 'show': {'title': 'The Pacific', 'ids': {'trakt': 2}}}]
EPS    = [{'type': 'episode', 'episode': {'title': 'Part One', 'number': 1, 'ids': {'trakt': 4, 'imdb': 'tt1480055'}}}]
RESP['/items/movie'] = FakeResp(json.dumps(MOVIES).encode())
RESP['/items/show'] = FakeResp(json.dumps(SHOWS).encode())
RESP['/items/season'] = FakeResp(json.dumps(SEASONS).encode())
RESP['/items/episode'] = FakeResp(json.dumps(EPS).encode())
RESP['/items/person'] = FakeResp(json.dumps(PERSON).encode())

out = trakt.Trakt.get_list_items.__wrapped__(t, '123')
assert out['persons'] == [{'name': 'Tom Hanks', 'id': '100'}], out['persons']
assert out['movies'][0]['uniqueid'] == {'trakt': 1, 'imdb': 'tt0114709'}
assert out['tvshows'][0]['uniqueid'] == {'trakt': 2, 'imdb': 'tt0374463'}

PCAST = {'cast': [{'character': 'Woody', 'movie': {'title': 'Toy Story', 'year': 1995, 'ids': {'imdb': 'tt0114709'}}}],
         'crew': [{'job': 'Director', 'movie': {'title': 'Crew Film', 'ids': {'imdb': 'tt0000000'}}}]}
SCAST = {'cast': [{'character': 'Colonel', 'show': {'title': 'The Pacific', 'year': 2010, 'ids': {'imdb': 'tt0374463'}}}],
         'crew': [{'job': 'Creator', 'show': {'title': 'Crew Show', 'ids': {'imdb': 'tt0000001'}}}]}
RESP['/people/100/movies'] = FakeResp(json.dumps(PCAST).encode())
RESP['/people/100/shows'] = FakeResp(json.dumps(SCAST).encode())

credits = trakt.Trakt.get_trakt_person.__wrapped__(t, '100')
assert sorted(credits) == ['movies', 'tvshows'], credits
assert len(credits['movies']) == 1 and credits['movies'][0]['title'] == 'Toy Story'
assert credits['movies'][0]['uniqueid'] == {'imdb': 'tt0114709'}
assert len(credits['tvshows']) == 1 and credits['tvshows'][0]['title'] == 'The Pacific'
assert not any('Crew' in item['title'] for key in credits for item in credits[key])

t2 = trakt.Trakt.__new__(trakt.Trakt)
t2.monitor = Mon()
t2.enabled = False
assert trakt.Trakt.get_lists.__wrapped__(t2) == []

t3 = trakt.Trakt.__new__(trakt.Trakt)
t3.monitor = Mon()
t3.enabled = True
t3.logo = 'trakt.png'
RESP['/users/false/lists'] = FakeResp(json.dumps(
    [{'name': 'My List', 'description': 'desc', 'ids': {'trakt': 42}}]).encode())
lst = trakt.Trakt.get_lists.__wrapped__(t3)
assert lst == [{'name': 'My List', 'description': 'desc', 'id': '42', 'icon': 'trakt.png'}], lst

import default as default_mod  # noqa: E402


def _serial_poolit(method):
    def wrapper(items=[], *args, **kwargs):
        return [method(item, *args, **kwargs) for item in items]
    return wrapper


default_mod.poolit = _serial_poolit


class FakeKodi:
    def progressBGDialog(self, *a, **k): return None
    def get_kodi_movies(self): return KODI_MOVIES
    def get_kodi_tvshows(self): return []
    def get_kodi_episodes(self): return []
    def get_kodi_seasons(self, *a, **k): return []


KODI_MOVIES = [{'title': 'RED', 'uniqueid': {'imdb': 'tt1245526', 'tmdb': '39514'}},
               {'title': 'Toy Story', 'uniqueid': {'imdb': 'tt0114709'}}]
sp = default_mod.SPGenerator.__new__(default_mod.SPGenerator)
sp.kodi = FakeKodi()
sp.dia = None
sp.msg = 'Matching'
sp.pct = 0
sp.cntpct = 0
sp.cnt = 0
sp.tot = 0

out = sp.match_items({'movies': [
    {'title': 'Bad', 'uniqueid': {'imdb': {'nested': 'x'}}},
    {'title': 'RED', 'uniqueid': {'imdb': 'tt1245526'}},
]})
assert [m['title'] for m in out['movies']] == ['RED'], out

print('test_imdb OK')
