# Network Library Sync — Design Spec

## Problem

Multiple Kodi instances share a MariaDB library database. When PowerToys scrapes content on the master instance, the new metadata is written to the shared DB. However, client instances don't automatically refresh their UI to show the new content. Users must manually refresh each client.

## Goal

When the master instance (running PowerToys) completes a library scan, automatically trigger a UI refresh on all discovered Kodi peers on the network. Clients do not need the addon installed.

## Architecture

```
PowerToys Instance (Master)          Plain Kodi (Client)
┌─────────────────────┐            ┌─────────────────────┐
│ PowerToys scrapes   │            │                     │
│ into shared MariaDB │            │                     │
│       │              │            │                     │
│       ▼              │            │                     │
│ OnScanFinished fires │            │                     │
│       │              │  HTTP POST │                     │
│  Container.Refresh ──────────────►│  UI refreshes       │
│  to all peers        │            │  (shows new data    │
│                       │            │   from shared DB)   │
└─────────────────────┘            └─────────────────────┘
```

### Key Properties

- **Master/Client model**: Only the PowerToys instance initiates sync. Clients are plain Kodi.
- **Shared MariaDB**: All instances point to the same library database. Scrape writes once, all instances see the data.
- **No remote scan commands**: Since the DB is shared, clients don't need to re-scrape. Only UI refresh is needed.
- **Zero-configuration discovery**: Uses Kodi's built-in Zeroconf (`_xbmc._tcp`) to find peers.
- **No loop risk**: Clients have no addon, can never broadcast back.

## Components

### 1. Peer Discovery

- Use `zeroconf` Python library to browse for `_xbmc._tcp.local.` services
- Each service provides: IP address, port, hostname
- Periodic refresh (every 30 seconds) to detect new/removed instances
- Self-exclusion: match discovered IPs against local IP to skip self

### 2. Scan Detection

- Hook into existing `Monitor.onNotification` in `service.py`
- Listen for `VideoLibrary.OnScanFinished` notification
- On fire: trigger broadcast to all discovered peers

### 3. UI Refresh Broadcast

- For each discovered peer (excluding self):
  - POST `{"jsonrpc":"2.0","method":"Container.Refresh","id":"kodi.powertoys.sync"}` to `http://{ip}:{port}/jsonrpc`
  - Use HTTP Basic Auth if the peer requires it (read from Zeroconf TXT records or configured credentials)
- Debounce: 5-second cooldown after broadcast to avoid duplicates

### 4. Settings

| Setting ID | Type | Default | Label ID | Description |
|------------|------|---------|----------|-------------|
| `Sync_Enabled` | bool | `false` | 32025 | Master switch — enables library sync refresh to network peers |

### 5. Localization

| String ID | English Text |
|-----------|-------------|
| 32025 | Sync Library Refresh to Network Peers |

## Files to Modify

| File | Changes |
|------|---------|
| `resources/settings.xml` | Add separator + `Sync_Enabled` toggle in new section |
| `resources/language/resource.language.en_gb/strings.po` | Add string 32025 |
| `resources/lib/service.py` | Add `SyncManager` class; hook into `Monitor.onNotification` |
| `resources/lib/globals.py` | Bundle `zeroconf` library (pure Python, no C dependencies) |
| `addon.xml` | No changes needed (zeroconf bundled, not an external dependency) |

## Edge Cases

| Scenario | Behavior |
|----------|----------|
| No peers discovered | No broadcast — silently skip |
| Peer goes offline | HTTP POST fails — ignore error, retry on next scan |
| Multiple rapid scans | Debounce prevents duplicate refresh commands within 5 seconds |
| Same IP appearing twice | Deduplicate by IP address |
| Peer requires auth | Use credentials from Zeroconf TXT records or skip if unavailable |

## Requirements on Clients

1. Kodi with remote control via HTTP enabled (Settings > Services > Remote Control)
2. Zeroconf enabled (Settings > Services > General)
3. No addon required
4. Must share the same MariaDB database as the master instance

## Testing

- Enable `Sync_Enabled` on master
- Verify peers are discovered via Zeroconf (check logs with debugging enabled)
- Trigger a library scan on master
- Verify clients receive `Container.Refresh` and UI updates
- Test peer goes offline gracefully
- Test multiple rapid scans don't flood clients
