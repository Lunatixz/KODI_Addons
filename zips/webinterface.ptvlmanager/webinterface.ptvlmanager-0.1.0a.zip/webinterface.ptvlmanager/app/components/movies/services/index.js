define([
    './genres',
    './moviesList',
    './moviesDetails'
], function () {});