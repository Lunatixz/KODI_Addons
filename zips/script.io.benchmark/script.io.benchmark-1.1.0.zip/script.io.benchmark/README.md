# I/O Benchmark

Default test paths : Plugin Folder, Settings Folder
Custom test paths  : RunScript(script.io.benchmark/default.py, paths=path1,path2,etc])