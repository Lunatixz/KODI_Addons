#   Copyright (C) 2018 Team-Kodi
#
#
# This file is part of Kodi Module Auditor
#
# Kodi Module Auditor is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Kodi Module Auditor is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Kodi Module Auditor.  If not, see <http://www.gnu.org/licenses/>.

import schedule
import xbmc

from scan import *

class Monitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self, xbmc.Monitor())
        self.pendingChange = False
        
        
    def onSettingsChanged(self):
        log("onSettingsChanged")
        self.pendingChange = True
        
        
class Service(object):
    def __init__(self):
        self.myMonitor = Monitor()
        self.myScanner = SCAN()
        self.myMonitor.waitForAbort(30) # startup delay
        self.myScanner.preliminary()    # initial scan
        self.startService()

         
    def startService(self):
        schedule.clear()
        self.myMonitor.pendingChange = False
        schedule.every(int(REAL_SETTINGS.getSetting('Scan_Wait'))).days.do(self.myScanner.preliminary) # run every x days
        while not self.myMonitor.abortRequested():
            if self.myMonitor.waitForAbort(30) or self.myMonitor.pendingChange: break
            if xbmc.getGlobalIdleTime() >= 900: continue # do not notify when idle
            schedule.run_pending()
        if self.myMonitor.pendingChange: self.startService()
        
if __name__ == '__main__': Service()