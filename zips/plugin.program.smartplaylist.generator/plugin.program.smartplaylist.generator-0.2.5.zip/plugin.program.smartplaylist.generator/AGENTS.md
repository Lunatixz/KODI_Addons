# AGENTS.md — Smartplaylist Generator

## Changelog rule (always do this)

Whenever you make an impactful, user-facing change, fix, or new feature to this addon,
**update the `<news>` changelog in `addon.xml`** in the same change. No exceptions.

- Add a concise bullet (or a `Version X.Y.Z` header, newest on top) under `<news>` in
  the `xbmc.addon.metadata` extension.
- Include only what users need to know: new features, new modules/settings, behavior
  changes, and bug fixes they'd notice.
- Skip plumbing-only internals (refactors, renaming, dead-code removal) unless they
  change observable behavior.
- Bump the addon `version` attribute when the change warrants a release-level note.

Checklist before finishing an impactful change: code done → tests pass → changelog updated.
