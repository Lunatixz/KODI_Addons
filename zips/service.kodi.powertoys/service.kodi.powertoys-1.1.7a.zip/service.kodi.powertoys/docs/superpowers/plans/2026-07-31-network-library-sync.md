# Network Library Sync Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** When PowerToys completes a library scan, automatically trigger a UI refresh on all discovered Kodi peers on the network via Zeroconf discovery and HTTP JSONRPC.

**Architecture:** A `SyncManager` class browses Kodi's built-in `_xbmc._tcp` Zeroconf services to discover peers. On `VideoLibrary.OnScanFinished`, it POSTs `Container.Refresh` to each peer's JSONRPC endpoint. A single `Sync_Enabled` setting controls the feature.

**Tech Stack:** Python 3, `zeroconf` library (pure Python, bundled), Kodi JSON-RPC API over HTTP

## Global Constraints

- Kodi addon Python API: `xbmc.python` version 3.0.0
- Addon ID: `service.kodi.powertoys`
- Existing dependencies: `script.module.kodi-six`, `script.module.simplecache`, `script.module.infotagger`
- Follow existing code style: no type hints, `log()` for debug output, `REAL_SETTINGS` for addon settings
- `zeroconf` library must be bundled in `resources/lib/zeroconf/` (pure Python, no C extensions)
- Clients must have remote control via HTTP enabled and Zeroconf enabled
- No external pip installs — everything bundled with the addon

---

## File Structure

| File | Action | Responsibility |
|------|--------|---------------|
| `resources/lib/zeroconf/` | Create (bundle) | Pure Python zeroconf library |
| `resources/settings.xml` | Modify | Add `Sync_Enabled` toggle |
| `resources/language/resource.language.en_gb/strings.po` | Modify | Add string 32025 |
| `resources/lib/service.py` | Modify | Add `SyncManager` class, hook `Monitor.onNotification` |

---

### Task 1: Bundle Zeroconf Library

**Files:**
- Create: `resources/lib/zeroconf/__init__.py` (and supporting modules)

**Interfaces:**
- Consumes: Nothing
- Produces: `zeroconf.ServiceBrowser`, `zeroconf.ServiceInfo`, `zeroconf.Zeroconf` classes available for import

- [ ] **Step 1: Download zeroconf package**

Download the `zeroconf` Python package from PyPI (version 0.150.0 or latest pure-Python release). Extract the source.

- [ ] **Step 2: Copy to resources/lib/zeroconf/**

Copy the zeroconf package files into `resources/lib/zeroconf/`. Ensure only pure Python files are included (no `.so`, `.pyd`, or C extension files).

- [ ] **Step 3: Verify import works**

Create a temporary test script and verify `from zeroconf import Zeroconf, ServiceBrowser, ServiceInfo` works within Kodi's Python environment.

- [ ] **Step 4: Commit**

```bash
git add resources/lib/zeroconf/
git commit -m "feat: bundle zeroconf library for peer discovery"
```

---

### Task 2: Add Settings and Localization

**Files:**
- Modify: `resources/settings.xml`
- Modify: `resources/language/resource.language.en_gb/strings.po`

**Interfaces:**
- Consumes: Nothing
- Produces: `Sync_Enabled` setting available via `REAL_SETTINGS.getSettingBool('Sync_Enabled')`

- [ ] **Step 1: Add localized string**

In `resources/language/resource.language.en_gb/strings.po`, add after the last msgctxt entry:

```po
msgctxt "#32025"
msgid "Sync Library Refresh to Network Peers"
msgstr ""
```

- [ ] **Step 2: Add setting to settings.xml**

In `resources/settings.xml`, add a new section before the Permissions separator (`<setting label="32018" type="lsep"/>`):

```xml
	<setting label="32025" type="lsep"/>
    <setting id="Sync_Enabled" type="bool" label="32025" default="false" />
```

- [ ] **Step 3: Verify setting is readable**

Write a quick Python snippet to confirm `REAL_SETTINGS.getSettingBool('Sync_Enabled')` returns `False` by default.

- [ ] **Step 4: Commit**

```bash
git add resources/settings.xml resources/language/resource.language.en_gb/strings.po
git commit -m "feat: add Sync_Enabled setting for network library sync"
```

---

### Task 3: Create SyncManager Class

**Files:**
- Modify: `resources/lib/service.py`

**Interfaces:**
- Consumes: `xbmc.Monitor.onNotification`, `REAL_SETTINGS.getSettingBool('Sync_Enabled')`, `log()` from globals
- Produces: `SyncManager.start()`, `SyncManager.stop()`, `SyncManager.broadcast_refresh()`

- [ ] **Step 1: Add SyncManager import and class skeleton**

At the top of `service.py`, after existing imports, add:

```python
import socket
import threading
import time
from zeroconf import Zeroconf, ServiceBrowser
```

- [ ] **Step 2: Add SyncManager class definition**

Add before the `Service` class:

```python
class SyncManager:
    SERVICE_TYPE = "_xbmc._tcp.local."
    REFRESH_COMMAND = {"jsonrpc": "2.0", "method": "Container.Refresh", "id": "kodi.powertoys.sync"}
    DEBOUNCE_SECONDS = 5

    def __init__(self):
        self.log('SyncManager.__init__')
        self.zeroconf = None
        self.browser = None
        self.peers = {}  # {ip: {"host": str, "port": int}}
        self._last_broadcast = 0
        self._lock = threading.Lock()

    def log(self, msg, level=xbmc.LOGDEBUG):
        log('SyncManager: %s' % msg, level)

    def start(self):
        if not REAL_SETTINGS.getSettingBool('Sync_Enabled'):
            self.log('Sync_Enabled is False, not starting')
            return
        self.log('Starting SyncManager')
        self.zeroconf = Zeroconf()
        self.browser = ServiceBrowser(self.zeroconf, self.SERVICE_TYPE, handlers=[self._on_service_found])

    def stop(self):
        self.log('Stopping SyncManager')
        if self.browser:
            self.browser.cancel()
        if self.zeroconf:
            self.zeroconf.close()

    def _on_service_found(self, zeroconf, service_type, name):
        try:
            info = zeroconf.get_service_info(service_type, name)
            if info:
                ip = socket.inet_ntoa(info.addresses[0]) if info.addresses else None
                if ip:
                    self._register_peer(ip, info.server, info.port)
        except Exception as e:
            self.log('_on_service_found error: %s' % e, xbmc.LOGWARNING)

    def _register_peer(self, ip, host, port):
        local_ip = self._get_local_ip()
        if ip == local_ip:
            self.log('Skipping self: %s' % ip)
            return
        with self._lock:
            if ip not in self.peers:
                self.log('New peer: %s:%d (%s)' % (ip, port, host))
            self.peers[ip] = {"host": host, "port": port}

    def _get_local_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def broadcast_refresh(self):
        if not REAL_SETTINGS.getSettingBool('Sync_Enabled'):
            return
        now = time.time()
        if now - self._last_broadcast < self.DEBOUNCE_SECONDS:
            self.log('Debounce: skipping refresh (last broadcast %.1fs ago)' % (now - self._last_broadcast))
            return
        self._last_broadcast = now
        self.log('Broadcasting Container.Refresh to %d peers' % len(self.peers))
        for ip, peer in list(self.peers.items()):
            self._send_refresh(ip, peer['port'])

    def _send_refresh(self, ip, port):
        try:
            import xbmcgui
            url = 'http://%s:%d/jsonrpc' % (ip, port)
            req = urllib.request.Request(url, data=json.dumps(self.REFRESH_COMMAND).encode('utf-8'))
            req.add_header('Content-Type', 'application/json')
            response = urllib.request.urlopen(req, timeout=5)
            self.log('Refresh sent to %s:%d (HTTP %d)' % (ip, port, response.getcode()))
        except Exception as e:
            self.log('Failed to send refresh to %s:%d: %s' % (ip, port, e), xbmc.LOGWARNING)
```

- [ ] **Step 3: Verify class structure compiles**

Import the class in a test context and confirm no syntax errors.

- [ ] **Step 4: Commit**

```bash
git add resources/lib/service.py
git commit -m "feat: add SyncManager class for zeroconf peer discovery and refresh broadcast"
```

---

### Task 4: Hook SyncManager into Service and Monitor

**Files:**
- Modify: `resources/lib/service.py`

**Interfaces:**
- Consumes: `SyncManager.start()`, `SyncManager.stop()`, `SyncManager.broadcast_refresh()`
- Produces: Service starts SyncManager on boot, Monitor calls `broadcast_refresh` on `OnScanFinished`

- [ ] **Step 1: Add SyncManager to Service.__init__**

In `Service.__init__`, after `self._tasks = self._load()`, add:

```python
        self.sync = SyncManager()
```

- [ ] **Step 2: Start SyncManager in Service._start**

In `Service._start`, after the `self.monitor.waitForAbort(self.wait)` line and before the main loop, add:

```python
        self.sync.start()
```

- [ ] **Step 3: Stop SyncManager on shutdown**

In `Service._start`, after the main loop exits and before `self._save()`, add:

```python
        self.sync.stop()
```

- [ ] **Step 4: Hook Monitor.onNotification for OnScanFinished**

In `Monitor.onNotification`, add a new condition after the existing `VideoLibrary.OnScanFinished` check:

```python
            elif method == "VideoLibrary.OnScanFinished":
                if self.service and hasattr(self.service, 'sync'):
                    self.service.sync.broadcast_refresh()
```

Note: This must be added alongside (not replacing) the existing `Clean_OnScanFinished` logic. The existing code checks `method == "VideoLibrary.OnScanFinished" and REAL_SETTINGS.getSettingBool('Clean_OnScanFinished')`. Add a separate `elif` for the sync broadcast.

- [ ] **Step 5: Verify no duplicate logic**

Read through the `onNotification` method to confirm both `Clean_OnScanFinished` and `SyncManager` broadcast can fire independently without conflict.

- [ ] **Step 6: Commit**

```bash
git add resources/lib/service.py
git commit -m "feat: hook SyncManager into Service and Monitor lifecycle"
```

---

### Task 5: Verify End-to-End Flow

**Files:**
- No new files — manual verification

**Interfaces:**
- Consumes: All previous tasks
- Produces: Confirmed working feature

- [ ] **Step 1: Enable Sync_Enabled on master instance**

In Kodi Settings > Add-ons > service.kodi.powertoys > Settings, enable "Sync Library Refresh to Network Peers".

- [ ] **Step 2: Verify Zeroconf discovery in logs**

Enable debugging (Settings > System > Logging > Enable Debug Logging). Start Kodi. Check `kodi.log` for `SyncManager: New peer` entries showing discovered instances.

- [ ] **Step 3: Trigger a library scan on master**

Right-click a source > "Scan for new content" or let PowerToys trigger a scrape.

- [ ] **Step 4: Verify Container.Refresh sent to peers**

Check `kodi.log` on master for `SyncManager: Refresh sent to` entries. Check that client instances refresh their UI.

- [ ] **Step 5: Test debounce**

Trigger two rapid scans. Verify only one `Refresh sent` log entry within the 5-second debounce window.

- [ ] **Step 6: Test graceful failure**

Temporarily disable remote control on a client. Verify master logs `Failed to send refresh` but does not crash.

- [ ] **Step 7: Commit (if any fixes needed)**

```bash
git add -A
git commit -m "fix: address issues found during end-to-end verification"
```

---

## Self-Review Checklist

- [ ] Spec coverage: Zeroconf discovery ✓, OnScanFinished detection ✓, Container.Refresh broadcast ✓, Sync_Enabled setting ✓, localization ✓, debounce ✓, self-exclusion ✓
- [ ] Placeholder scan: No TBD/TODO in plan
- [ ] Type consistency: `SyncManager.start()`, `.stop()`, `.broadcast_refresh()` used consistently across Tasks 3 and 4
