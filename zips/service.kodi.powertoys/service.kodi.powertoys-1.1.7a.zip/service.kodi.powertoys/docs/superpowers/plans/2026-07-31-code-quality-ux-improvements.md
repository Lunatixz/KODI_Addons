# PowerToys Code Quality & UX Improvement Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix 6 bugs, remove dead code, improve code quality, and polish UX across the entire addon.

**Architecture:** Single-file changes organized by file — globals.py, service.py, settings.xml, strings.po. No new files needed.

**Tech Stack:** Python 3, Kodi addon API, PO localization

## Global Constraints

- Kodi addon Python API: `xbmc.python` version 3.0.0
- Addon ID: `service.kodi.powertoys`
- Follow existing code style: no type hints, `log()` for debug output, `REAL_SETTINGS` for addon settings
- Preserve all existing functionality — only fix bugs, remove dead code, improve labels

---

## File Structure

| File | Action | Responsibility |
|------|--------|---------------|
| `resources/lib/globals.py` | Modify | Fix notification(), remove dead code, cache local IP |
| `resources/lib/service.py` | Modify | Fix scrapeMovies return, remove dead code, fix imports |
| `resources/lib/cqueue.py` | No change | Already clean |
| `resources/settings.xml` | Modify | Reorganize settings groups |
| `resources/language/.../strings.po` | Modify | Fix typos, improve labels, add descriptions |
| `addon.xml` | Modify | Add summary |

---

### Task 1: Fix globals.py Bugs + Dead Code

**Files:**
- Modify: `resources/lib/globals.py`

**Interfaces:**
- Consumes: Nothing
- Produces: Fixed `notification()`, fixed `sendJSON()`, removed unused code

- [ ] **Step 1: Fix notification() sound parameter**

In `globals.py`, line 137, change `sound=False` to `sound=sound`:

```python
def notification(message, header=ADDON_NAME, sound=False, time=4000, icon=ICON, show=None):
    log('notificationDialog: %s, show = %s'%(message,show))
    if show:
        try:    xbmcgui.Dialog().notification(header, message, icon, time, sound=sound)
        except: xbmc.executebuiltin("Notification(%s, %s, %d, %s)" % (header, message, time, icon))
    return True
```

- [ ] **Step 2: Fix sendJSON() input mutation**

In `globals.py`, change `sendJSON` to copy the input dict:

```python
def sendJSON(param):
    command = dict(param)
    command["jsonrpc"] = "2.0"
    command["id"] = ADDON_ID
    log('sendJSON param [%s]'%(param))
    response = loadJSON(xbmc.executeJSONRPC(dumpJSON(command)))
    if response.get('error'): log('sendJSON, failed! error = %s\n%s'%(dumpJSON(response.get('error')),command), xbmc.LOGWARNING)
    return response
```

- [ ] **Step 3: Remove unused imports**

In `globals.py`, line 19, remove `base64, zlib` (only used by dead `decodeString`):

```python
import time, traceback, json, os, platform, re
import datetime, heapq, random, sys
```

- [ ] **Step 4: Remove dead functions**

Remove these functions entirely from `globals.py`:
- `decodeString()` (lines 112-116)
- `slugify()` (lines 118-124)
- `isPlaying()` (lines 101-102) — unused in service logic
- `timeit()` (lines 84-90) — unused anywhere
- `getInfoBool()` (lines 95-96) — unused

- [ ] **Step 5: Remove unused constant**

Remove `THREAD_WORKERS = os.cpu_count() * 2` (line 41) — never used.

- [ ] **Step 6: Commit**

```bash
git add resources/lib/globals.py
git commit -m "fix: globals.py bugs, dead code removal, notification sound fix"
```

---

### Task 2: Fix service.py Bugs + Dead Code

**Files:**
- Modify: `resources/lib/service.py`

**Interfaces:**
- Consumes: Nothing
- Produces: Fixed `scrapeMovies`, removed dead methods, fixed imports

- [ ] **Step 1: Fix scrapeMovies return value**

In `service.py`, `scrapeMovies` method — add `return True` after the files check:

```python
def scrapeMovies(self, path, movies=[]):
    if not path or not xbmcvfs.exists(path):
        self.log('scrapeMovies, path not accessible: %s' % path, xbmc.LOGWARNING)
        return False
    files = (self.getDirectory(path) or [])
    if len(files) > 0: 
        self.log('scrapeMovies path = %s, files = %s'%(path,len(files)))
        items = dict([(self._pathKey(self._directoryPath(movie['file'])),movie) for movie in movies if movie.get('file')])
        random.shuffle(files)
        for file in files:
            if   self.monitor.waitForAbort(0.01): return False
            elif not self._pathKey(file.get('file')) in items:
                self._tasks.setdefault('scrapeDirectory',set()).add(file.get('file'))
    return True
```

- [ ] **Step 2: Remove _menu() method**

Remove the empty `_menu` method (lines 230-234) from Service class.

- [ ] **Step 3: Remove parseEpisodes() method**

Remove the unused `parseEpisodes` method (lines 617-641) from Service class.

- [ ] **Step 4: Remove commented-out decorator**

Remove the commented-out `@cacheit` line (line 310) above `getDirectory`.

- [ ] **Step 5: Add explicit threading import**

In `service.py`, add `import threading` to the imports section (don't rely on transitive import through globals):

```python
from globals import *
from cqueue  import CustomQueue
from zeroconf import Zeroconf, ServiceBrowser
import socket, urllib.request, threading
```

- [ ] **Step 6: Commit**

```bash
git add resources/lib/service.py
git commit -m "fix: scrapeMovies return value, remove dead code, fix imports"
```

---

### Task 3: Fix strings.po Typos + Improve Labels

**Files:**
- Modify: `resources/language/resource.language.en_gb/strings.po`

**Interfaces:**
- Consumes: Nothing
- Produces: Fixed typos, improved labels, added descriptions

- [ ] **Step 1: Fix typos**

Fix these strings:
- Line 84: "Ingore NFO Meta" → "Ignore NFO Meta"
- Line 96: "entires" → "entries"

- [ ] **Step 2: Improve ambiguous labels**

Update these strings for clarity:
- `#32002`: "Start Delay/Service Interval (Seconds)" → "Service Start Delay (Seconds)"
- `#32004`: "Show Dialog" → "Show Scraper Progress Dialog"
- `#32015`: "Include Episodes" → "Include Episodes in TV Refresh"

- [ ] **Step 3: Add addon metadata descriptions**

Fill in the empty msgstr fields:

```po
msgctxt "Addon Summary"
msgid ""
msgstr "Automated library maintenance: scraping, refresh, cleaning, and network sync."

msgctxt "Addon Description"
msgid ""
msgstr "PowerToys automates Kodi library maintenance. Scrapes new content from configured source folders, periodically refreshes metadata, removes duplicate library entries, and syncs UI refresh across network peers."

msgctxt "Addon Disclaimer"
msgid ""
msgstr "Use at your own risk. Dry Run is enabled by default."
```

- [ ] **Step 4: Commit**

```bash
git add resources/language/resource.language.en_gb/strings.po
git commit -m "fix: typos, improve setting labels, add addon descriptions"
```

---

### Task 4: Reorganize settings.xml

**Files:**
- Modify: `resources/settings.xml`

**Interfaces:**
- Consumes: Nothing
- Produces: Better organized settings with clear visual grouping

- [ ] **Step 1: Reorganize settings into logical groups**

Rewrite `settings.xml` with clear sections:

```xml
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<settings>
    <setting label="32001" type="lsep"/>
    <setting id="Scraper_Enabled" type="bool" label="32010" default="false" />
    <setting id="Scraper_Show_Dialog" type="bool" label="32004" default="true" subsetting="true" />
    <setting id="Scraper_Interval_DAYS" type="number" label="32003" default="1" subsetting="true" />
    <setting id="Scraper_TV_Folder" type="folder" label="32007" source="video" option="writeable" default="" subsetting="true" />
    <setting id="Scraper_Movie_Folder" type="folder" label="32008" source="video" option="writeable" default="" subsetting="true" />
    <setting id="Refresh_Enabled" type="bool" label="32005" default="false" />
    <setting id="Refresh_Interval_DAYS" type="number" label="32006" default="7" subsetting="true" />
    <setting id="Refresh_Include_Episodes" type="bool" label="32015" default="true" subsetting="true" />
    <setting id="Refresh_Ignore_NFO" type="bool" label="32013" default="false" subsetting="true" />
    <setting id="Refresh_Clean" type="bool" label="32012" default="false" />
    <setting id="Clean_OnScanFinished" type="bool" label="32023" default="false" />
    <setting label="32025" type="lsep"/>
    <setting id="Sync_Enabled" type="bool" label="32025" default="false" />
    <setting label="32018" type="lsep"/>
    <setting id="Dry_Run_Enabled" type="bool" label="32016" default="true" />
    <setting id="Delete_Enabled" type="bool" label="32017" default="false" />
    <setting label="32000" type="lsep"/>
    <setting id="Enable_Debugging" type="bool" label="32000" default="false" />
    <setting id="Run_Playing" type="bool" label="32011" default="false" />
    <setting id="Run_Idling" type="bool" label="32014" default="true" />
    <setting id="Start_Delay" type="number" label="32002" default="15" />
</settings>
```

- [ ] **Step 2: Commit**

```bash
git add resources/settings.xml
git commit -m "refactor: reorganize settings into logical groups"
```

---

### Task 5: Update addon.xml

**Files:**
- Modify: `addon.xml`

**Interfaces:**
- Consumes: Nothing
- Produces: Populated addon summary

- [ ] **Step 1: Add summary to addon.xml**

In `addon.xml`, fill in the empty summary tag:

```xml
<summary lang="en_GB">Automated library maintenance: scraping, refresh, cleaning, and network sync.</summary>
```

- [ ] **Step 2: Commit**

```bash
git add addon.xml
git commit -m "fix: add addon summary description"
```

---

### Task 6: Final Verification

- [ ] **Step 1: Run syntax check on all Python files**

```bash
python -m py_compile resources/lib/globals.py
python -m py_compile resources/lib/service.py
python -m py_compile resources/lib/cqueue.py
```

- [ ] **Step 2: Verify settings.xml is valid XML**

```bash
python -c "import xml.etree.ElementTree as ET; ET.parse('resources/settings.xml'); print('XML valid')"
```

- [ ] **Step 3: Verify strings.po has no duplicate msgctxt**

```bash
python -c "
with open('resources/language/resource.language.en_gb/strings.po') as f:
    lines = [l.strip() for l in f if l.startswith('msgctxt')]
dupes = [l for l in lines if lines.count(l) > 1]
print('Duplicates:', dupes if dupes else 'None')
"
```

- [ ] **Step 4: Verify no references to removed functions**

```bash
python -c "
with open('resources/lib/service.py') as f:
    content = f.read()
for fn in ['_menu', 'parseEpisodes', 'decodeString', 'slugify', 'isPlaying', 'timeit', 'getInfoBool', 'THREAD_WORKERS']:
    if fn in content:
        print(f'WARNING: {fn} still referenced')
    else:
        print(f'OK: {fn} removed')
"
```

---

## Self-Review Checklist

- [ ] Spec coverage: All 6 bugs fixed ✓, dead code removed ✓, code quality improved ✓, UX polished ✓
- [ ] Placeholder scan: No TBD/TODO in plan
- [ ] Type consistency: All function signatures preserved, no breaking changes
