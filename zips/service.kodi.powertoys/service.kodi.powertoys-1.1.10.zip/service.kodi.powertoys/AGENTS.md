# Project Instructions

## Changelog Maintenance (MANDATORY)

Whenever you make a user-facing change or add a feature to this addon, you MUST update the `<news>` section in `addon.xml` before finishing.

- Include impactful, user-visible changes and features (bug fixes that affect behavior, new settings, new capabilities).
- Skip internal refactors, dead-code removal, and changes with no observable effect on the user.
- Prefix each entry with `v<new-version> (YYYY-MM-DD)` when the version is bumped; otherwise append to the current version's list.
- Bump `version="X.Y.Z"` in the `<addon>` tag when you add a changelog entry for new behavior.

## Other Conventions

- Kodi addon: Python 3, `kodi_six` compatibility layer, no type hints on public helpers.
- Follow existing code style: `log()` for debug output, `REAL_SETTINGS` for settings access, `sendJSON` for JSON-RPC.
- Never add a new dependency when a few lines of stdlib/codebase code suffice.
- When changing cached queries (SimpleCache keyed by `ADDON_VERSION`), bump the addon version so stale results are invalidated.
