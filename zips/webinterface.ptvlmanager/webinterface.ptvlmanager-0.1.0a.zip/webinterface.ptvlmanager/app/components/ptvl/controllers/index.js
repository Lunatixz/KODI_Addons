define([
    './channels',
    './ptvlInfo',
    './../min/controllers/type.min',
    './channel-types/index',
     './../min/controllers/subRules.min'
], function () {});