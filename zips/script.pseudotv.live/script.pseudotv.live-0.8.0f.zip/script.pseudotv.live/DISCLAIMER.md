# [COLOR=blue]Privacy disclaimer:[/COLOR]

- PseudoTV Live accepts no liability for password security. While every effort has been made to protect your information, it can not be guaranteed.
    
- PseudoTV Live accepts no liability for the contents of email/media, or for the consequences of any actions taken on the basis of the information provided. Any information or files presented/attached in email are solely those of the author and do not necessarily represent those of the software developer.

# [COLOR=blue]Content disclaimer:[/COLOR]

- PseudoTV Live does not provided content/media, its sole purpose is to aggregate and propagate media from various third party sites and services. The legality of the media provided depends on user configurations. PseudoTV Live does not condone copyright infringement, piracy and the circumvention of regional/encryption locks. 

- PseudoTV Live contains links to websites operated by third parties, The links are provided for your convenience. PseudoTV Live does not control such websites/media and are not responsible for the content and performance of these sites or for your transactions with them. Inclusion of links to such websites does not imply an endorsement or any association with their operators.

# [COLOR=blue]Terms of use:[/COLOR]

- PseudoTV Live can not be held liable for the misuse of this software. Content/Media configurations made by the user are solely their responsibility.

- PseudoTV Live is never deployed "Preconfigured", "Bundled", or Sold as a retail product. PseudoTV Live is a [B]non-profit[/B] donation driven project.

- Kodi is a trademark of the XBMC Foundation

# [COLOR=red]DO NOT[/COLOR] use this software or its services to solicit/spam sites and services. Repeat offenders will be permanently banned from community access.

By continuing the use of this software you agree to the above terms, else un-install immediately. Thank You...

