#   Copyright (C) 2025 Lunatixz
#
#
# This file is part of Smartplaylist Generator.
#
# Smartplaylist Generator is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Smartplaylist Generator is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PseudoTV Live.  If not, see <http://www.gnu.org/licenses/>.
#
# -*- coding: utf-8 -*-
from globals  import *
from parsers  import trakt, mdblist, openrouter
from kodi     import Kodi
from xsp      import XSP

try:    from simplecache             import SimpleCache
except: from simplecache.simplecache import SimpleCache #pycharm stub

class SPGenerator:
    dia    = None
    msg    = ''
    pct    = 0
    tot    = 0
    cnt    = 0
    cntpct = 0
    
    def __init__(self, sysARG=sys.argv):
        self.log('__init__, sysARG = %s'%(sysARG))
        self.cache  = SimpleCache()
        self.cache.enable_mem_cache = False
        
        self.sysARG    = sysARG
        self.kodi      = Kodi(self.cache)
        self.xsp       = XSP()
        self.modules   = {LANGUAGE(32100):trakt.Trakt(self.cache),LANGUAGE(32300):mdblist.MDBList(self.cache),LANGUAGE(32200):openrouter.OpenRouter(self.cache)}
        self._build_times = self._load_build_times()


    def _build_times_path(self):
        return os.path.join(xbmcvfs.translatePath(SETTINGS_LOC), 'build_times.json')


    def _load_build_times(self):
        try:
            with open(self._build_times_path(), 'r') as f: return json.load(f)
        except: return {}


    def _save_build_times(self):
        try:
            path = self._build_times_path()
            os.makedirs(os.path.dirname(path), exist_ok=True)
            tmp = '%s.tmp'%(path)
            with open(tmp, 'w') as f: json.dump(self._build_times, f)
            os.replace(tmp, path)
        except Exception as e: self.log('_save_build_times, failed: %s'%e, xbmc.LOGERROR)


    def log(self, msg, level=xbmc.LOGDEBUG):
        return log('%s: %s'%(self.__class__.__name__,msg),level)
        
        
    def auto_lists(self):
        for source, module in list(self.modules.items()):
            try: self.log('auto_lists, source = %s, saving = %s'%(source,self.kodi.setCacheSetting('%s.%s'%(ADDON_ID,source),[{'name':item.get('name'),'id':item.get('id'),'icon':item.get('icon',ICON)} for item in module.get_lists()])))
            except Exception: pass
        
        
    def build_lists(self, source, lists):
        def __buildMenu(item): return self.kodi.buildMenuListItem(item.get('name'),item.get('description'),item.get('icon',ICON),url=item.get('id'))
        with self.kodi.busy_dialog(): listitems = poolit(__buildMenu)(lists)
        selects = self.kodi.selectDialog(listitems,header='%s %s'%(source,ADDON_NAME),preselect=self.kodi.findItemsInLST(listitems, self.kodi.getCacheSetting('%s.%s'%(ADDON_ID,source)), item_key='getPath', val_key='id'),)
        if not selects is None: self.log('build_lists, source = %s, saving = %s'%(source,self.kodi.setCacheSetting('%s.%s'%(ADDON_ID,source),[{'name':listitems[select].getLabel(),'id':listitems[select].getPath(),'icon':listitems[select].getArt('icon')} for select in selects])))
        

    @staticmethod
    def _norm(title):
        return re.sub(r'[^a-z0-9]', '', (title or '').lower())


    def match_items(self, source_items, by_title=False):
        matches   = {}
        func_list = {'movies'  : self.kodi.get_kodi_movies,
                     'tvshows' : self.kodi.get_kodi_tvshows,
                     'seasons' : self.kodi.get_kodi_tvshows,
                     'episodes': self.kodi.get_kodi_episodes}

        def __match(list_item, type, index, titles, eps, by_title):
            uniqueid = list_item.get('uniqueid') or {}
            kodi_item = None
            # 1) Authoritative: match on a real unique id when present.
            for key in list(uniqueid.keys()):
                value = uniqueid.get(key)
                if isinstance(value, (dict, list)): continue
                kodi_item = index.get((key, value))
                if kodi_item: break
            # 2) AI fallback: episodes match by show + season + episode when
            #    available, else title AND year must both hit a real entry.
            if not kodi_item and by_title:
                if type == 'episodes' and list_item.get('season') is not None:
                    kodi_item = eps.get((self._norm(list_item.get('showtitle')), str(list_item.get('season') or ''), str(list_item.get('episode') or '')))
                if not kodi_item:
                    title = self._norm(list_item.get('title'))
                    year  = str(list_item.get('year') or '')
                    kodi_item = titles.get((title, year)) if year else titles.get((title, ''))
            if kodi_item:
                self.log('match_items, __match found! type %s | %s -> %s'%(type,kodi_item.get('uniqueid'),list_item.get('uniqueid')))
                if type == "seasons": return self.kodi.get_kodi_seasons(kodi_item, list_item) or None
                return [kodi_item]
            return None

        for type, list_items in list(source_items.items()):
            if not list_items or type not in func_list: continue
            self.log('match_items, type %s | list_items = %s'%(type, len(list_items)))
            index  = {}
            titles = {}
            eps    = {}
            for kodi_item in func_list.get(type)():
                for key, value in list((kodi_item.get('uniqueid') or {}).items()):
                    if isinstance(value, (dict, list)): continue
                    index.setdefault((key, value), kodi_item)
                nkey = self._norm(kodi_item.get('title'))
                titles.setdefault((nkey, str(kodi_item.get('year') or '')), kodi_item)
                titles.setdefault((nkey, ''), kodi_item)
                if type == 'episodes':
                    eps.setdefault((self._norm(kodi_item.get('showtitle')), str(kodi_item.get('season') or ''), str(kodi_item.get('episode') or '')), kodi_item)
            self.msg = '%s %s'%(LANGUAGE(32022),type.title().replace('Tvshows','TV Shows'))
            if self.dia: self.dia = self.kodi.progressBGDialog(self.pct, self.dia, self.msg)
            # Collect ordered results from poolit so API item order is preserved
            # and shared state is never mutated from worker threads.
            if type == 'seasons':
                matched_groups = poolit(__match)(list_items, **{'type':type,'index':index,'titles':titles,'eps':eps,'by_title':by_title})
            else:
                matched_groups = [__match(item, type=type, index=index, titles=titles, eps=eps, by_title=by_title) for item in list_items]
            for group in matched_groups:
                if group: matches.setdefault(type, []).extend(group)
        return matches


    def _playlists_exist(self, name):
        # True when at least one <name> - *.xsp exists in the playlists folder.
        # On any error assume they exist so we don't block/rebuild spuriously.
        try:
            files, _ = xbmcvfs.listdir(xbmcvfs.translatePath(REAL_SETTINGS.getSetting('XSP_LOC')))
            prefix = '%s - ' % (validString(name))
            return any(f.endswith('.xsp') and f.startswith(prefix) for f in files)
        except Exception:
            return True


    def build_person(self, module, person):
        name = person.get('name')
        self.log('build_person, name = %s, id = %s'%(name, person.get('id')))
        tmlLST = self.match_items(module.get_trakt_person(person.get('id')))
        if tmlLST: self.xsp.create(name, tmlLST, uid='person.%s'%(person.get('id')))


    def run(self, param="None"):
        if param.startswith(('Build_','Select_')):
            source = param.split('_')[1]
            module = self.modules.get(source) 
            if not module: return
            self.log('run, %s source = %s, module = %s'%(param.split('_')[0], source,module.__class__.__name__))
                
            if 'Select_' in param and not self.kodi.isRunning(source):
                with self.kodi.busy_dialog(), self.kodi.setRunning(source):
                    tmlLST = module.get_lists()
                    self.log("run, get_lists\n%s"%(tmlLST))
                    self.build_lists(source, tmlLST)
                REAL_SETTINGS.openSettings()
                    
            elif 'Build_' in param and not self.kodi.isRunning(source):
                if REAL_SETTINGS.getSettingBool('Enable_%s'%(source)):
                    auto = param.endswith('_auto')
                    with self.kodi.setRunning(source):
                        list_items = self.kodi.getCacheSetting('%s.%s'%(ADDON_ID,source))
                        if not list_items:
                            list_items = [{'name':item.get('name'),'id':item.get('id'),'icon':item.get('icon',ICON)} for item in module.get_lists()]
                            self.kodi.setCacheSetting('%s.%s'%(ADDON_ID,source), list_items)
                        if len(list_items) > 0:
                            self.pct = 0
                            self.dia = self.kodi.progressBGDialog(self.pct)
                            for idx, list_item in enumerate(list_items):
                                list_id  = list_item.get('id')
                                build_key = '%s.%s'%(source, list_id)
                                if auto:
                                    last = self._build_times.get(build_key, 0)
                                    if last and (time.time() - last) < REAL_SETTINGS.getSettingInt('Run_Every_Hours')*3600 and self._playlists_exist(list_item.get('name')):
                                        self.log('run, skipping %s, last built %s'%(list_item.get('name'),datetime.datetime.fromtimestamp(last).strftime(DTFORMAT)))
                                        continue
                                self.pct = int((idx+1)*100//len(list_items))
                                self.dia = self.kodi.progressBGDialog(self.pct, self.dia, message='%s:\n%s'%(ADDON_NAME,list_item.get('name')))
                                tmlLST = dict(module.get_list_items(list_id) or {})
                                persons = tmlLST.pop('persons', [])
                                self.log("run, get_list_items\n%s"%(tmlLST))
                                matches = self.match_items(tmlLST, by_title=getattr(module, 'match_mode', '') == 'title')
                                self.xsp.create(list_item.get('name'), matches, uid='%s.%s'%(source,list_id))
                                for person in persons: self.build_person(module, person)
                                if matches:
                                    self._build_times[build_key] = time.time()
                                    self._save_build_times()
                                REAL_SETTINGS.setSetting('Build_%s'%(source),datetime.datetime.fromtimestamp(time.time()).strftime(DTFORMAT))
                            self.dia = self.kodi.progressBGDialog(100, self.dia)
                            self.kodi.executebuiltin('Container.Refresh')
                        else: self.kodi.notificationDialog(LANGUAGE(32023)%(source))
            else: self.kodi.notificationDialog(LANGUAGE(32025)%(ADDON_NAME))

        elif param == 'Run_All':
            if REAL_SETTINGS.getSettingBool('Auto_Enable'): self.auto_lists()
            for source in list(self.modules.keys()):
                self.kodi.executebuiltin('RunScript(special://home/addons/%s/resources/lib/default.py, Build_%s_auto)'%(ADDON_ID,source), wait=True)
            REAL_SETTINGS.setSetting('Last_Update',datetime.datetime.fromtimestamp(time.time()).strftime(DTFORMAT))
        elif self.kodi.yesnoDialog('%s?'%(LANGUAGE(32110))):
            self.kodi.executebuiltin('RunScript(special://home/addons/%s/resources/lib/default.py, Run_All)'%(ADDON_ID))
        else:
            REAL_SETTINGS.openSettings()
        

if __name__ == '__main__': SPGenerator(sys.argv).run(sys.argv[1] if len(sys.argv) > 1 else 'None')

