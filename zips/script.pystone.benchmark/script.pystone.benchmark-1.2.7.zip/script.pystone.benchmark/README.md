# PYSTONE CPU Benchmark
